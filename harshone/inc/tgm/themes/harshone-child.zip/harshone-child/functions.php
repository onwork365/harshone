<?php
/**
 * Harshone Child Theme functions and definitions.
 *
 * @package Harshone_Child
 * @since 1.0.0
 */

 if ( ! defined( 'ABSPATH' ) ) {
 	exit; // Exit if accessed directly.
 }

 /**
  * Define Child Theme Version for proper cache busting.
  */
 define( 'HARSHONE_CHILD_VERSION', '1.0.0' );

 /**
  * Enqueue parent and child theme styles.
  */
 if ( ! function_exists( 'harshone_child_enqueue_styles' ) ) {
 	function harshone_child_enqueue_styles() {
 		// Enqueue parent theme's style.css
 		wp_enqueue_style( 'harshone-parent-style', get_template_directory_uri() . '/style.css', array(), HARSHONE_VERSION );

 		// Enqueue child theme's style.css
 		wp_enqueue_style( 'harshone-child-style', get_stylesheet_directory_uri() . '/style.css', array( 'harshone-parent-style' ), HARSHONE_CHILD_VERSION );

        // If you have specific child theme JS, enqueue it here:
        // wp_enqueue_script( 'harshone-child-script', get_stylesheet_directory_uri() . '/assets/js/child-script.js', array( 'jquery' ), HARSHONE_CHILD_VERSION, true );
 	}
 	add_action( 'wp_enqueue_scripts', 'harshone_child_enqueue_styles' );
 }

// Add any other child theme specific functions, hooks, or customizations below this line.
// Example: Add a custom post type only for the child theme
/*
function harshone_child_register_custom_post_type() {
    register_post_type( 'portfolio',
        array(
            'labels' => array(
                'name' => __( 'Portfolios', 'harshone-child' ),
                'singular_name' => __( 'Portfolio', 'harshone-child' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'portfolio'),
            'show_in_rest' => true,
        )
    );
}
add_action( 'init', 'harshone_child_register_custom_post_type' );
*/